// Environment configuration
// For React Native, these will be set at runtime
export const ENV = {
  SUPABASE_URL: 'https://ktvrffbccgxtaststlhw.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_sNhpQ5W6i_KuIPcT6bjjnw_BcJwPljV',
  OPENAI_API_KEY: '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',
  APP_ENV: 'development' as const,
  API_TIMEOUT: 30000,
};

// This will be populated at runtime from App.tsx
export const initializeEnv = (config: Partial<typeof ENV>): void => {
  if (config.SUPABASE_URL) ENV.SUPABASE_URL = config.SUPABASE_URL;
  if (config.SUPABASE_ANON_KEY) ENV.SUPABASE_ANON_KEY = config.SUPABASE_ANON_KEY;
  if (config.OPENAI_API_KEY) ENV.OPENAI_API_KEY = config.OPENAI_API_KEY;
  if (config.APP_ENV) ENV.APP_ENV = config.APP_ENV;
  if (config.API_TIMEOUT) ENV.API_TIMEOUT = config.API_TIMEOUT;
};

// Validate required environment variables
export const validateEnv = (): void => {
  const required = ['SUPABASE_URL', 'SUPABASE_ANON_KEY'];
  const missing = required.filter((key) => !ENV[key as keyof typeof ENV]);
  
  if (missing.length > 0) {
    console.warn(`Missing environment variables: ${missing.join(', ')}`);
  }
};
