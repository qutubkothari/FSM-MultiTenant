import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from '../types';
import { authService } from '../services/supabase';

interface AuthState {
  user: User | null;
  isLoading: boolean;
  error: string | null;
  login: (phone: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  setUser: (user: User | null) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isLoading: false,
      error: null,

      login: async (phone: string, password: string) => {
        set({ isLoading: true, error: null, user: null });
        try {
          const userData = await authService.loginWithPhone(phone, password);
          const user: User = {
            ...userData,
            role: userData.role as 'admin' | 'salesman',
          };
          set({ user, isLoading: false, error: null });
        } catch (error: any) {
          const errorMessage = error?.message || 'Login failed';
          set({ error: errorMessage, isLoading: false, user: null });
          throw error;
        }
      },

      logout: async () => {
        set({ isLoading: true });
        try {
          await authService.logout();
          set({ user: null, isLoading: false });
        } catch (error: any) {
          set({ error: error.message, isLoading: false });
        }
      },

      setUser: (user) => set({ user }),
    }),
    {
      name: 'fsm_user',
      partialize: (state) => ({ user: state.user }),
    }
  )
);
