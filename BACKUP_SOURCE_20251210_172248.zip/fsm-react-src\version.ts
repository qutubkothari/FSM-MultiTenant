// Application version
// Update this for each build:
// - x.x.01, x.x.02, etc. for minor bug fixes
// - x.1.0, x.2.0, etc. for major changes
export const APP_VERSION = '1.1.0';
export const BUILD_DATE = '2025-11-26';
