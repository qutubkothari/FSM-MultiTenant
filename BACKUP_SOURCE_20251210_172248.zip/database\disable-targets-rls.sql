-- Disable RLS on salesman_targets to allow super admin operations
ALTER TABLE salesman_targets DISABLE ROW LEVEL SECURITY;
